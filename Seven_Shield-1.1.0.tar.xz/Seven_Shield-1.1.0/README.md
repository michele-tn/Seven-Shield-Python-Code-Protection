# Seven Shield

> Python Code Protection Studio — seven AST-based layers, processed entirely on your machine.

Seven Shield is a local desktop application for protecting Python source code through seven independently selectable transformations:

- **Rename** — replaces internal identifiers with visually ambiguous names.
- **Encrypt** — protects strings and packages the compiled result inside a compressed, masked payload.
- **Flatten** — converts function bodies into state machines.
- **Hide Builtins** — resolves Python built-ins indirectly at runtime.
- **Hide Imports** — replaces static imports with dynamic module loading.
- **Hide Attrs** — replaces readable attribute access with `getattr` calls.
- **Junk Code** — inserts harmless opaque branches and dead code.

All processing happens locally. Obfuscation increases the cost of reverse engineering, but it cannot make recovery impossible because Python must ultimately execute the program. Always keep the original source in version control and run your test suite against every protected release.

When **Encrypt** is enabled, Seven Shield emits an aggressive loader with `I/l` identifiers and a masked compiled payload. Run the protected file with the same Python major and minor version used to generate it.

## Windows quick start

Python 3.11 or later is required.

Download [`Seven_Shield-1.1.0.tar.xz`](Seven_Shield-1.1.0.tar.xz) and verify it against [`Seven_Shield-1.1.0.tar.xz.sha256`](Seven_Shield-1.1.0.tar.xz.sha256) before extracting it.

```powershell
Get-FileHash .\Seven_Shield-1.1.0.tar.xz -Algorithm SHA256
```

Double-click **`Avvia_Seven_Shield.bat`**.

On the first launch, the script creates `.venv` and installs the project. Later launches open the GUI immediately without reinstalling it. Paths containing spaces are supported.

The project showcase is [index.html](index.html). It can be published directly with GitHub Pages by selecting the root of the default branch as the deployment source.

To run the application manually without installing it:

```powershell
$env:PYTHONPATH = "src"
python -m seven_shield.gui
```

## Command line

```powershell
.venv\Scripts\seven-shield source.py -o source.protected.py --seed 42
```

All seven layers are enabled by default. Disable individual transformations with options such as `--no-flatten` or `--no-junk-code`.

## Tests

```powershell
python -m unittest discover -s tests -v
```

## Project structure

```text
Avvia_Seven_Shield.bat       First-time setup and Windows launcher
index.html                   Responsive GitHub Pages showcase
src/seven_shield/
  gui.py                     Desktop interface
  cli.py                     Command-line interface
  obfuscator.py              Seven-layer AST transformation engine
tests/
  test_obfuscator.py         Behavioral equivalence tests
pyproject.toml               Package configuration and entry points
```

## Security expectations

Seven Shield is an intellectual-property protection tool, not a cryptographic vault. A determined analyst can eventually recover executable behavior. Treat protected files as generated release artifacts and never edit them in place.

## License

Distributed under the [MIT License](LICENSE).
